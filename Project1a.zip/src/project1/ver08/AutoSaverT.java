package project1.ver08;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Writer;

public class AutoSaverT extends Thread {
	

	@Override
	public void run() {
		try {
			while (true) {
				sleep(1000);
				System.out.println("주소록이 텍스트로 자동저장되었습니다.");
			}
		}catch (InterruptedException e) {}

	}

}