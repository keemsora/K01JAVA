package project1.ver09;

public class Iconnect {

}
