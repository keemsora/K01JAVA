package project1.ver09;

import java.sql.SQLException;
import java.util.Scanner;

public class SearchData extends ConnectDB {
	
	
	Scanner scan = new Scanner(System.in);
	
	public SearchData() {
		super();
	}
	
	@Override
	void execute() {
		try{
			stmt = con.createStatement();
			
			System.out.println("이름:");
			String searchName = scan.nextLine();
			
			String query = "SELECT * FROM phonebook_tb "
					+ "WHERE name like '"+searchName+"'";
			rs = stmt.executeQuery(query);
			
			while(rs.next()) {
				String name = rs.getString("name");
				String phNum = rs.getString("phNum");
				String birthday = rs.getString("birthday");
				
				System.out.printf("이름:%s\n 전화번호:%s 생년월일:%s\n", name, phNum, birthday);
			}
		}
		catch(SQLException e ) {
			System.out.println("포함된 이름을 검색할 수 없습니다.");
			e.printStackTrace();
		}
		finally {
			close();
		}

		
	}
}

