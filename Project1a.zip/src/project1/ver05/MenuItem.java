package project1.ver05;

public interface MenuItem {
	
	public static final int 데이터입력 = 1;
	public static final int 데이터검색 = 2;
	public static final int 데이터삭제 = 3;
	public static final int 출력 = 4;
	public static final int 프로그램종료 = 5;

}


