package project1.ver07;

public interface MenuItem {
	
	public static final int Input = 1;
	public static final int	Search = 2;
	public static final int Delete = 3;
	public static final int Print = 4;
	public static final int Exit= 5;

}


