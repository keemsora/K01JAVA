package project1.ver07;

public interface SubMenuItem {
	
	public static final int Basic = 1;
	public static final int Uni = 2;
	public static final int Com = 3;
	
}
