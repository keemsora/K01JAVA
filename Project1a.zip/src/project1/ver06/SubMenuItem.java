package project1.ver06;

public interface SubMenuItem {
	
	public static final int 일반 = 1;
	public static final int 학교동창 = 2;
	public static final int 회사동료 = 3;
	
}
